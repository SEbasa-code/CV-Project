<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Project</title>
    <link rel="stylesheet" href="skills.css">
</head>
<body>
    <header class="header">
        <a href="#" class="logo">Sebastian.</a>
        <nav class="navbar">
            <a href="CV.php">Home</a>
            <a href="personalinfo.php">Personal Info</a>
            <a href="education.php">Education</a>
            <a href="experiance.php">Experiance</a>
            <a href="#" class="active">Skills</a>
            <a href="contacts.php">Contact</a>
            <a href="login.php">Logout</a>
        </nav>
    </header>
    <div class="container">
        <main class="row">
            <section class="col skills-section">
                <h2>Technical Skills</h2>
                <div class="skills-grid" id="skills-container">
                    <!-- Skills will be dynamically added here -->
                </div>
                <input type="text" id="skill-name" placeholder="Skill Name" class="skill-input">
                <input type="range" id="skill-level" min="0" max="100" value="0" class="skill-input">
                <button id="add-skill">Add Skill</button>
            </section>
        </main>
    </div>
    <script src="scripts.js"></script>
</body>
</html>



